package com.example.training10;

public class Books {
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public boolean isSwitch1() {
        return switch1;
    }

    public void setSwitch1(boolean switch1) {
        this.switch1 = switch1;
    }

    private String author;
    private int page;
    private boolean switch1;

    public Books(String title, String author, int page, boolean switch1) {
        this.title = title;
        this.author = author;
        this.page = page;
        this.switch1 = switch1;
    }




}
