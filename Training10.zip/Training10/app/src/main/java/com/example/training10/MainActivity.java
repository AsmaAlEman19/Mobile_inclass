package com.example.training10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private Switch SW;
    private Button btnAdd;
    private Button SBtn;
    private SharedPreferences Prefs;
    private SharedPreferences.Editor editor;

   ArrayList<Books> Book= new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1= findViewById(R.id.title);
        editText2= findViewById(R.id.name);
        editText3= findViewById(R.id.id);
        SW= findViewById(R.id.sw);
        SetUp();


    }

    private void SetUp(){
        Prefs= PreferenceManager.getDefaultSharedPreferences(this);
        editor= Prefs.edit();
    }

    public void bthAdd(View view) {
        String title1= editText1.getText().toString().trim();
        String author= editText2.getText().toString().trim();
        int pages= Integer.parseInt(editText3.getText().toString().trim());
        Boolean sw1= SW.isChecked();
        Book.add(new Books(title1,author, pages, sw1));


    }
    public void stbn(View view) {
        SetUp();

        Gson gson= new Gson();
        String str= gson.toJson(Book);
        editor.putString("",str);
        editor.commit();
        Toast.makeText(this, "Has Been Added"
                +str, Toast.LENGTH_SHORT).show();


    }
}
